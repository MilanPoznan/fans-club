import React from 'react'

export default function SignupScreen() {
  return (
    <div>
      <h2>Pick role</h2>
      <button>Artist</button>
      <button>User</button>
    </div>
  )
}
